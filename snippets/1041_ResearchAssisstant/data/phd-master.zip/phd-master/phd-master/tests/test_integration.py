import os
import json
from fastapi.testclient import TestClient
import pytest

from app.main import app, gh_client


@pytest.fixture(autouse=True)
def env_setup(tmp_path, monkeypatch):
    # Use mock LangGraph and local test repo
    monkeypatch.setenv("MOCK_LANGGRAPH", "1")
    repo_path = os.path.join(os.path.dirname(__file__), "test_repo")
    monkeypatch.setenv("LOCAL_REPO_PATH", repo_path)
    # Ensure logs dir is writable
    monkeypatch.setenv("PYTHONWARNINGS", "ignore")
    yield


def test_end_to_end_flow(monkeypatch):
    client = TestClient(app)

    # Start a thread
    r = client.post("/mcp/start_thread", json={"name": "integration-test"})
    assert r.status_code == 200
    thread = r.json()
    thread_id = thread["thread_id"] if "thread_id" in thread else thread.get("thread_id")
    assert thread_id

    # Plan changes using mock manager
    r = client.post("/mcp/plan_changes", json={"thread_id": thread_id, "instruction": "Add note about camera mount left side."})
    assert r.status_code == 200
    plan = r.json()
    assert plan["thread_id"] == thread_id
    proposals = plan["proposed_changes"]
    assert isinstance(proposals, list) and len(proposals) >= 1

    # Monkeypatch GitHubClient methods to simulate branch/commit/diff/pr using local files
    created_branches = {}

    def fake_create_branch(branch_name, base="master"):
        created_branches["branch"] = branch_name
        return branch_name

    def fake_update_or_create_files(branch, changes, commit_message="msg"):
        # write files under tests/.branches/<branch>/
        base = os.path.join(os.path.dirname(__file__), ".branches")
        branch_dir = os.path.join(base, branch)
        os.makedirs(branch_dir, exist_ok=True)
        changed = []
        for ch in changes:
            p = os.path.join(branch_dir, ch["path"]) if isinstance(ch, dict) else os.path.join(branch_dir, ch.path)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(ch["content"])
            changed.append(ch["path"])
        return changed

    def fake_get_branch_diff(branch, base="master"):
        # Compare tests/test_repo vs .branches/<branch>
        base_dir = os.path.join(os.path.dirname(__file__), "test_repo")
        branch_dir = os.path.join(os.path.dirname(__file__), ".branches", branch)
        files = []
        if not os.path.exists(branch_dir):
            return None
        for root, _, filenames in os.walk(branch_dir):
            for fn in filenames:
                rel = os.path.relpath(os.path.join(root, fn), branch_dir).replace("\\", "/")
                files.append({"filename": rel, "status": "modified", "additions": 1, "deletions": 0, "patch": None})
        return {"base": base, "branch": branch, "files": files}

    def fake_create_pull_request(title, body, head_branch, base="master"):
        return {"url": f"https://example.com/pr/{head_branch}", "number": 1, "title": title}

    monkeypatch.setattr(gh_client, "create_branch", fake_create_branch)
    monkeypatch.setattr(gh_client, "update_or_create_files", fake_update_or_create_files)
    monkeypatch.setattr(gh_client, "get_branch_diff", fake_get_branch_diff)
    monkeypatch.setattr(gh_client, "create_pull_request", fake_create_pull_request)

    # Propose changes (use the proposals returned earlier)
    changes_payload = {"branch_name": None, "summary": "Integration test change", "conversation_id": "testconv", "changes": proposals}
    r = client.post("/mcp/propose_changes", json=changes_payload)
    assert r.status_code == 200
    prop = r.json()
    branch = prop["branch"]

    # Get diff
    r = client.post("/mcp/get_diff", params={"branch": branch})
    assert r.status_code == 200
    diff = r.json()
    assert diff["branch"] == branch
    assert isinstance(diff["files"], list)

    # Create PR
    r = client.post("/mcp/create_pull_request", json={"branch": branch, "title": "Integration PR", "description": "From test", "base": "master"})

    assert r.status_code == 200
    pr = r.json()
    assert pr["url"]
