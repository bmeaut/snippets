import os
from fastapi.testclient import TestClient
import pytest

from app.main import app, gh_client


@pytest.fixture(autouse=True)
def set_env_tmp_path(tmp_path, monkeypatch):
    # point LOCAL_REPO_PATH to our test repo
    repo_path = os.path.join(os.path.dirname(__file__), "test_repo")
    monkeypatch.setenv("LOCAL_REPO_PATH", repo_path)
    monkeypatch.setattr(gh_client, "repo", None)
    monkeypatch.setattr(gh_client, "local_path", repo_path)
    yield



def test_health():
    client = TestClient(app)
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_get_project_context():
    client = TestClient(app)
    r = client.post("/mcp/get_project_context")
    assert r.status_code == 200
    body = r.json()
    assert "repo" in body
    assert isinstance(body.get("top_level"), list)
    assert body.get("project_guide") is not None


def test_list_directory_root():
    client = TestClient(app)
    r = client.post("/mcp/list_directory", json={"path": "", "recursive": False, "branch": "master"})
    assert r.status_code == 200
    body = r.json()
    assert "entries" in body
    names = [e["name"] for e in body["entries"]]
    assert "README.md" in names
    assert "docs" in names


def test_list_directory_recursive():
    client = TestClient(app)
    r = client.post("/mcp/list_directory", json={"path": "", "recursive": True, "branch": "master"})
    assert r.status_code == 200
    body = r.json()
    paths = [e["path"] for e in body["entries"]]
    assert "docs/sample.txt" in paths


def test_list_directory_not_found():
    client = TestClient(app)
    r = client.post("/mcp/list_directory", json={"path": "non_existent_dir_xyz"})
    assert r.status_code == 404
    assert "not found" in r.json()["detail"].lower()


def test_get_file_content_success():
    client = TestClient(app)
    r = client.post("/mcp/get_file_content", json={"path": "README.md", "branch": "master"})
    assert r.status_code == 200
    body = r.json()
    assert body["path"] == "README.md"
    assert body["branch"] == "master"
    assert "content" in body
    assert body["sha"]


def test_get_file_content_not_found():
    client = TestClient(app)
    r = client.post("/mcp/get_file_content", json={"path": "missing.txt", "branch": "master"})
    assert r.status_code == 404
    assert "not found" in r.json()["detail"].lower()


def test_get_file_content_is_directory():
    client = TestClient(app)
    r = client.post("/mcp/get_file_content", json={"path": "docs", "branch": "master"})
    assert r.status_code == 400
    assert "directory" in r.json()["detail"].lower()


def test_delete_file_default_branch_prohibited():
    client = TestClient(app)
    r = client.post("/mcp/delete_file", json={"path": "README.md", "branch": "master"})
    assert r.status_code == 400
    assert "default branch" in r.json()["detail"].lower()


def test_delete_file_success():
    client = TestClient(app)
    repo_path = os.path.join(os.path.dirname(__file__), "test_repo")
    target_file = os.path.join(repo_path, "temp_to_delete.txt")
    with open(target_file, "w", encoding="utf-8") as f:
        f.write("temporary file")

    try:
        r = client.post("/mcp/delete_file", json={"path": "temp_to_delete.txt", "branch": "feature/test-branch"})
        assert r.status_code == 200
        body = r.json()
        assert body["path"] == "temp_to_delete.txt"
        assert body["branch"] == "feature/test-branch"
        assert body["deleted"] is True
        assert body["sha"]
        assert not os.path.exists(target_file)
    finally:
        if os.path.exists(target_file):
            os.remove(target_file)


def test_delete_file_not_found():
    client = TestClient(app)
    r = client.post("/mcp/delete_file", json={"path": "non_existent_file.txt", "branch": "feature/test-branch"})
    assert r.status_code == 404
    assert "not found" in r.json()["detail"].lower()


def test_create_pull_request_twice_idempotency(monkeypatch):
    client = TestClient(app)
    call_count = 0

    def fake_create_pull_request(title, body, head_branch, base=None):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return {"url": "https://github.com/test/repo/pull/1", "number": 1, "title": title, "already_existed": False}
        else:
            return {"url": "https://github.com/test/repo/pull/1", "number": 1, "title": title, "already_existed": True}

    monkeypatch.setattr(gh_client, "create_pull_request", fake_create_pull_request)

    # First call
    r1 = client.post("/mcp/create_pull_request", json={"branch": "feature/duplicate", "title": "Test PR", "description": "Test body", "base": "master"})
    assert r1.status_code == 200
    b1 = r1.json()
    assert b1["url"] == "https://github.com/test/repo/pull/1"
    assert b1["already_existed"] is False

    # Second call on same branch
    r2 = client.post("/mcp/create_pull_request", json={"branch": "feature/duplicate", "title": "Test PR", "description": "Test body", "base": "master"})
    assert r2.status_code == 200
    b2 = r2.json()
    assert b2["url"] == "https://github.com/test/repo/pull/1"
    assert b2["already_existed"] is True




