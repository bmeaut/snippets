# Project Guide

This file defines how the AI assistant should navigate, interpret, and modify this repository.

**Read this file before proposing or making any repository changes.**

---

## 1. Repository Structure

The repository is organized into functional areas:

```text
PhD/
├── PROJECT_GUIDE.md
├── README.md
│
├── 00_INBOX/
├── 01_PROJECT/
├── 02_LITERATURE/
├── 03_SOFTWARE/
├── 04_HARDWARE/
├── 05_EXPERIMENTS/
├── 06_FIELD_NOTES/
├── 07_MEETINGS/
├── 08_DECISIONS/
├── 09_MEDIA/
├── 10_PUBLICATIONS/
└── 99_ARCHIVE/
```

The structure is configurable. Do not assume that every folder must exist or that every project must use every folder.

### `00_INBOX/`

Temporary landing area for information that has not yet been classified.

Use this folder when information is potentially relevant but its final location is unclear.

The assistant should periodically suggest moving or processing inbox material.

Do not leave important, finalized knowledge in the inbox indefinitely.

### `01_PROJECT/`

Core project-level information.

Use for:

* research objectives
* research questions
* scope
* methodology
* project overview
* research framework
* current state of the project
* roadmap
* project terminology

This should describe the project as a whole rather than individual experiments or decisions.

### `02_LITERATURE/`

Knowledge derived from external literature.

Use for:

* papers
* books
* articles
* literature notes
* theoretical concepts
* literature reviews
* bibliographic information
* comparisons between relevant works

Always distinguish information obtained from a source from the assistant's own interpretation.

Preserve bibliographic provenance whenever possible.

### `03_SOFTWARE/`

Software-related project material.

Use for:

* source code
* software architecture
* implementation notes
* APIs
* technical documentation
* software experiments
* development decisions specific to software

### `04_HARDWARE/`

Hardware and physical-system information.

Use for:

* hardware architecture
* components
* fabrication
* electronics
* physical prototypes
* hardware specifications
* hardware-related design decisions

### `05_EXPERIMENTS/`

Experiments and empirical investigations.

Use for:

* experiment plans
* protocols
* observations
* results
* analyses
* experiment-specific conclusions

Raw experimental data should be preserved and should not be overwritten by the assistant.

Distinguish clearly between:

* planned experiments
* performed experiments
* observations
* measured results
* interpretations
* conclusions

Never invent experimental results.

### `06_FIELD_NOTES/`

Observations and notes originating from fieldwork or direct observation.

Use for:

* field observations
* site visits
* interviews
* informal observations
* contextual notes
* photographs or media references associated with observations

Preserve the distinction between direct observation and subsequent interpretation.

### `07_MEETINGS/`

Records of meetings and discussions.

Use for:

* supervision meetings
* research meetings
* workshops
* consultations
* meeting notes
* action items

When possible, record:

* date
* participants
* topics
* decisions
* action items

Important decisions identified in meeting notes may also belong in `08_DECISIONS/`.

### `08_DECISIONS/`

Durable project decisions.

Use for decisions that should remain part of the project's long-term memory.

Examples:

* methodological decisions
* architectural decisions
* research-design decisions
* changes in scope
* decisions about software or hardware architecture
* decisions about terminology or conceptual models

A decision record should preferably include:

* date
* decision
* context
* reasoning
* alternatives considered
* consequences
* source/provenance

Do not duplicate large amounts of content from meeting notes or conversations. Link to the original source where possible.

### `09_MEDIA/`

Media and media-related metadata.

Use for:

* images
* diagrams
* videos
* audio
* visualizations
* media indexes
* references to external media

Do not unnecessarily duplicate large binary files.

### `10_PUBLICATIONS/`

Tamás's own authored or co-authored publications arising from this research — not literature by other authors (that belongs in `02_LITERATURE/`).

Use for:

* submitted or published journal/conference papers
* preprints and working drafts
* thesis chapters and the dissertation itself
* co-authored papers, with clear attribution
* camera-ready and revision-history versions where relevant

Each publication gets one canonical Markdown document (per §12) with frontmatter, plus the actual submittable file (PDF/DOCX) alongside it when applicable.

### `99_ARCHIVE/`

Historical material that should be preserved but is no longer part of the active working knowledge base.

Use for:

* obsolete documents
* superseded versions
* completed project material
* historical conversation archives
* deprecated structures

**Archive rather than delete whenever historical provenance matters.**

---

## 2. Conversation Archive

Historical AI conversations may be stored under the archive area, for example:

```text
99_ARCHIVE/
└── CONVERSATIONS/
    ├── CHATGPT/
    ├── CLAUDE/
    └── GEMINI/
```

Conversation archives are historical records, not canonical project knowledge.

Do not automatically treat statements made in old conversations as current project decisions.

When extracting useful information from conversations:

1. identify the relevant claim, idea, decision, or question;
2. determine whether it is still relevant;
3. preserve its provenance;
4. update the appropriate active knowledge file if appropriate.

---

## 3. Choosing Where New Information Belongs

Before creating a file, determine whether an appropriate existing file already exists.

Prefer updating an existing canonical document over creating many small duplicate files.

Use this general decision rule:

```text
Project-wide information       → 01_PROJECT/
Literature-derived information → 02_LITERATURE/
Software information            → 03_SOFTWARE/
Hardware information            → 04_HARDWARE/
Experiments                     → 05_EXPERIMENTS/
Field observations              → 06_FIELD_NOTES/
Meetings                        → 07_MEETINGS/
Durable decisions               → 08_DECISIONS/
Media                           → 09_MEDIA/
Own publications                → 10_PUBLICATIONS/
Historical/superseded material  → 99_ARCHIVE/
Unclassified/new material       → 00_INBOX/
```

If information clearly belongs in more than one category, prefer:

1. one canonical source;
2. links or references from other relevant documents.

Avoid unnecessary duplication.

---

## 4. File Creation Rules

Before creating a new file:

1. Search the repository for related information.
2. Determine whether an existing document can be updated.
3. Check whether the proposed file would duplicate existing knowledge.
4. Follow existing naming conventions.
5. Prefer descriptive, stable filenames.
6. Add YAML frontmatter per §12.1. No separate index file is required.

Do not create files merely because a conversation contains a new thought.

Create a new document when the information represents a distinct, durable piece of knowledge that does not fit naturally into an existing document.

---

## 5. Documentation Changes

When the user asks to update the project based on a conversation:

1. Read `PROJECT_GUIDE.md`.
2. Inspect the current repository state.
3. Search for relevant existing documents.
4. Identify which documents are affected.
5. Determine whether information is new, changed, or already documented.
6. Propose the smallest coherent set of changes.
7. Preserve provenance.
8. Present the proposed changes for review.
9. Apply changes only after explicit approval.

Do not blindly append conversation transcripts to project documents.

Transform conversations into useful project knowledge.

---

## 6. Provenance

Important information should retain enough provenance to determine where it came from.

Possible sources include:

* user conversation
* meeting
* field observation
* experiment
* literature
* external source
* assistant-generated interpretation

When the information originates from an AI conversation, record the conversation/thread identifier when available.

Do not represent an assistant inference as if it were a user observation or established fact.

---

## 7. Research Integrity

The assistant must not:

* fabricate results;
* fabricate citations;
* invent experiments;
* invent observations;
* silently delete research material;
* overwrite raw data;
* present speculation as established fact;
* change the meaning of a user's research without making the change explicit.

When uncertain, ask the user rather than guessing.

---

## 8. Git Workflow

The `main` branch represents the approved project state.

The assistant must **never modify `main` directly**.

Repository changes should normally follow:

```text
Current main
    ↓
Create working branch
    ↓
Inspect relevant files
    ↓
Propose changes
    ↓
User approval
    ↓
Commit changes
    ↓
Create Pull Request
    ↓
User reviews
    ↓
Merge into main
```

Pull requests should contain:

* concise description of the change;
* reason for the change;
* affected files;
* provenance/thread information when applicable;
* any uncertainties or unresolved questions.

---

## 9. Open Pull Requests

An open Pull Request represents a **proposed project state**, not the canonical project state.

When answering questions about the current project:

* treat `main` as the authoritative approved state;
* consider open PRs as pending proposals;
* do not silently treat unmerged changes as established facts.

If the user explicitly asks about a pending proposal, inspect the relevant PR.

---

## 10. Updating Knowledge from Conversations

The assistant should distinguish between:

### Temporary discussion

Ideas being explored but not yet accepted.

These normally remain in the conversation and should not automatically modify canonical documentation.

### Candidate knowledge

An idea that appears important enough to preserve but has not yet been confirmed.

Consider placing it in `00_INBOX/` or an appropriate draft document.

### Established knowledge

A conclusion, decision, observation, or fact that the user has explicitly accepted or that is clearly supported by project evidence.

This may be incorporated into the appropriate canonical document.

The assistant should not turn every conversational statement into permanent project knowledge.

---

## 11. General Principles

The repository should remain useful without an AI assistant.

Therefore:

* Markdown should remain human-readable.
* Git history should preserve evolution.
* Important decisions should be understandable independently of the original conversation.
* The assistant should improve organization rather than create unnecessary complexity.
* Existing structure should be respected before introducing new structure.
* Prefer simple solutions over elaborate automation.
* Preserve historical information when it has research value.

---

## 12. Single Canonical Document & Website-Ready Frontmatter Convention

Each content folder maintains **one canonical, thoroughly synthesized Markdown document per distinct topic** (e.g. `01_...md` files) rather than many small per-conversation files. When new source material (a conversation, meeting, paper) is processed:

1. Fold its content into the relevant existing canonical document, or create a new canonical document if it covers a genuinely distinct topic.
2. Do not leave the raw per-conversation working file behind in the content folder once its content has been merged — remove it from the working tree (retaining a copy under `99_ARCHIVE/CONVERSATIONS/` if the verbatim source has independent research value; see §2).
3. This keeps each folder easy to browse by a human, an AI assistant, or eventually a static site generator, without needing a separate index file.

### 12.1 Frontmatter (required on all canonical documents)

Every canonical Markdown document opens with a small YAML frontmatter block so the file maps directly onto a single page of a future website:

```yaml
---
title: <Human-readable page title>
category: <folder name, e.g. 02_LITERATURE>
date: <YYYY-MM-DD, last substantive update>
slug: <kebab-case URL slug>
summary: <one or two sentence summary for listings/SEO>
---
```

* `slug` should be stable once published; treat renaming a slug like renaming a public URL.
* `summary` should be usable verbatim as a page preview/meta description.
* A static site generator can enumerate every canonical document, read its frontmatter, and generate one page per file plus listing pages per `category` — no separate index database required.

### 12.2 Deprecated: In-document Provenance & Source Conversations

Tracking individual AI conversation JSON files within canonical Markdown document bodies was **deprecated on 2026-08-23**. All ongoing research interaction and documentation edits are conducted directly with the AI assistant, rendering per-file conversation tracking unnecessary. Git history and commits serve as the primary audit trail for changes.

### 12.3 Deprecated: per-folder INDEX.md

An earlier version of this guide (PR #4) required a separate `INDEX.md` per folder. That approach is **deprecated as of 2026-08-23** in favor of the single-canonical-document convention above — with one well-synthesized file per topic, a separate index adds maintenance overhead without adding navigability. Any remaining `INDEX.md` files are historical pointers only and should not be treated as a source of truth; consult the canonical document(s) in the folder directly.

---

**The repository is the long-term project memory.
Conversations are the working space.
Git history is the provenance of changes.
The user remains the final authority on canonical project knowledge.**
