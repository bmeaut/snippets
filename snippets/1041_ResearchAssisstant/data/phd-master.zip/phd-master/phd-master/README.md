# PhD Research Assistant (MVP)

Minimal FastAPI service providing an MCP-like tool gateway for interacting with a GitHub-hosted PhD repository.

## Quick Start (Local Development)

1. Copy `.env.example` to `.env` and set `GITHUB_TOKEN` and `GITHUB_REPO` (owner/repo).
2. Create a virtualenv and install:

```bash
python -m venv .venv
source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
```

3. Run the service:

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Endpoints

Core MCP-like endpoints:
- `GET /health` – health check
- `POST /mcp/get_project_context` – returns compact project summary
- `POST /mcp/list_directory` – list files & subdirectories at a path (with optional recursion and branch)
- `POST /mcp/get_file_content` – returns raw text content of a single file at a given path & branch
- `POST /mcp/delete_file` – delete a file on a non-default feature branch
- `POST /mcp/get_file` – returns contents of a file in the repository (legacy endpoint)
- `POST /mcp/propose_changes` – create a branch with proposed file edits
- `POST /mcp/get_diff` – compare branch against master
- `POST /mcp/create_pull_request` – create a GitHub PR (idempotent; returns existing PR with `already_existed: true` if already open, and surfaces exact API errors on genuine failures)



LangGraph orchestration endpoints:
- `POST /mcp/start_thread` – start a conversational thread, returns a `thread_id`
- `GET /mcp/get_thread?thread_id=...` – fetch thread state and checkpoints
- `POST /mcp/checkpoint?thread_id=...` – save a JSON checkpoint for a thread
- `POST /mcp/plan_changes` – ask the orchestration manager to propose change(s) for a thread

## Workflow (MVP)

1. `POST /mcp/start_thread` to create a thread and capture repository context.
2. During conversation, call `POST /mcp/plan_changes` with `thread_id` and an instruction.
3. Review the returned `proposed_changes` and call `/mcp/propose_changes` to create a branch with the proposed edits.
4. Use `/mcp/get_diff` and `/mcp/create_pull_request` to create a PR for review.

## LangGraph Configuration

### Option 1: In-Process Mock (Default, Recommended for Dev)

Set `MOCK_LANGGRAPH=1` in `.env`. The service uses an in-memory orchestration manager with no external dependencies.

### Option 2: Local HTTP Mock Server

Run a local LangGraph mock HTTP server:

```bash
python run_local_langgraph.py
# or with custom port:
LANGGRAPH_MOCK_PORT=9001 python run_local_langgraph.py
```

Then set in `.env`:
```
LANGGRAPH_URL=http://127.0.0.1:9001
```

### Option 3: Hosted LangGraph

Set environment variables in `.env`:
- `LANGGRAPH_URL` — base URL for the LangGraph HTTP API (e.g. `https://langgraph.example/api`)
- `LANGGRAPH_API_KEY` — API key or bearer token for authentication

## Deployment

To deploy to the cloud (so you can access from your phone anywhere), see [DEPLOYMENT.md](DEPLOYMENT.md).

Quick links:
- **Render.com** (free tier available) — [See DEPLOYMENT.md](DEPLOYMENT.md#deployment-rendercom)
- **Fly.io** (generous free tier) — [See DEPLOYMENT.md](DEPLOYMENT.md#deployment-flyio)
- **Railway.app** (simple, pay-as-you-go) — Use similar Docker + env var approach

## Development

### Run Tests

```bash
pytest -q
```

### Run Integration Tests

Exercises the full flow (start thread → plan changes → propose changes → diff → PR) against the in-process mock:

```bash
pytest tests/test_integration.py -q
```

### View API Docs

Start the service and open:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Architecture

- **FastAPI** — HTTP API layer (MCP-like gateway)
- **PyGithub** — GitHub API client (with local fallback for dev)
- **LangGraph Orchestration** — Configurable (in-process mock, local HTTP, or hosted)
- **Audit Logging** — JSON-lines audit trail in `logs/audit.log`
- **Checkpointing** — Persistent thread state in `.langgraph/`

## Environment Variables

| Variable | Required | Default | Example |
|----------|----------|---------|---------|
| `GITHUB_TOKEN` | Yes | - | `ghp_xxxx` |
| `GITHUB_REPO` | Yes | - | `owner/repository` |
| `MOCK_LANGGRAPH` | No | `1` | `1` (use in-process mock) |
| `LANGGRAPH_URL` | No | - | `https://langgraph.example/api` |
| `LANGGRAPH_API_KEY` | No | - | Bearer token for LangGraph |
| `LOCAL_REPO_PATH` | No | - | `/path/to/repo` (local fallback for dev) |
| `PORT` | No | `8000` | `8000` |

## Next Steps

- [ ] Add endpoint authentication (API keys)
- [ ] Integrate with Claude mobile via MCP bridge
- [ ] Add semantic search to repository context
- [ ] Enhance planning logic with LLM-backed diff generation
- [ ] Set up monitoring and alerts
- [ ] Add persistent database for large-scale state

## License

MIT
