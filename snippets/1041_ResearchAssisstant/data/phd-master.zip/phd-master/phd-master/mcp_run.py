#!/usr/bin/env python
"""
Entrypoint for running the MCP server
Set PHDA_API_URL to your API endpoint (default: http://localhost:8000)
"""
import sys
from app.mcp_server import mcp

if __name__ == "__main__":
    mcp.run()
