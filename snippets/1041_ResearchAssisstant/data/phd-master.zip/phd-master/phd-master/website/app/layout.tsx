import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Link from 'next/link';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Title of the site goes here',
  description:
    'Description of the site goes here. This will be used in the meta description tag for SEO purposes.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        {/* KaTeX's stylesheet - required for the $$...$$ math blocks in the
            software architecture docs to render as typeset equations rather
            than raw LaTeX source or unstyled text. */}
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css"
          integrity="sha384-nB0miv6/jRmo5UMMR1wu3Gz6NLsoTkbqJghGIsx//Rlm+ZU03BU6SQNC66uf4l5+"
          crossOrigin="anonymous"
        />
      </head>
      <body>
        <header className="site-header">
          <Link href="/" className="site-title-link">
            Title of the site goes here
          </Link>
          <span className="site-mark">BME AUT — PhD Research Log</span>
        </header>
        {children}
      </body>
    </html>
  );
}
