import Link from 'next/link';
import { notFound } from 'next/navigation';
import { CATEGORIES, getCategory, getDocContent, getDocsForCategory } from '@/lib/docs';

export function generateStaticParams() {
  return CATEGORIES.flatMap((c) =>
    getDocsForCategory(c.slug).map((doc) => ({ category: c.slug, slug: doc.slug }))
  );
}

export const dynamicParams = false;

export default async function DocPage({
  params,
}: {
  params: { category: string; slug: string };
}) {
  const category = getCategory(params.category);
  if (!category) notFound();

  const doc = await getDocContent(category.slug, params.slug);
  if (!doc) notFound();

  return (
    <main className="wrap">
      <Link href={`/${category.slug}`} className="crumb">
        ← {category.label}
      </Link>
      <article>
        <div className="doc-meta">
          {category.code} — {category.label}
          {doc.date ? ` — ${doc.date}` : ''}
        </div>
        <header className="doc-head">
          <h1>{doc.title}</h1>
        </header>
        <div className="doc-body" dangerouslySetInnerHTML={{ __html: doc.html }} />
      </article>
    </main>
  );
}
