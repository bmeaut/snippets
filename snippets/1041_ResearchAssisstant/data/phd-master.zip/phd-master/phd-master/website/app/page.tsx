import Link from 'next/link';
import { CATEGORIES, getDocsForCategory } from '@/lib/docs';

export default function HomePage() {
  const rows = CATEGORIES.map((c) => ({ ...c, count: getDocsForCategory(c.slug).length }));

  return (
    <main className="wrap">
      <section className="hero">
        <span className="eyebrow">PhD Research — Automation &amp; Applied Informatics, BME</span>
        <h1>Title of the Research Project</h1>
        <p>
          Description of the research project goes here. This is a placeholder text that can be replaced with the actual description of the research project. It provides an overview of the objectives, methodologies, and expected outcomes of the research.
        </p>
      </section>

      <nav className="toc" aria-label="Repository sections">
        {rows.map((c) => (
          <Link key={c.slug} href={`/${c.slug}`} className="toc-row">
            <span className="toc-code">{c.code}</span>
            <span>
              <span className="toc-label">{c.label}</span>
              <span className="toc-desc">{c.description}</span>
            </span>
            <span className="toc-count">{c.count === 1 ? '1 doc' : `${c.count} docs`}</span>
          </Link>
        ))}
      </nav>
    </main>
  );
}
