import Link from 'next/link';
import { notFound } from 'next/navigation';
import { CATEGORIES, getCategory, getDocsForCategory } from '@/lib/docs';

export function generateStaticParams() {
  return CATEGORIES.map((c) => ({ category: c.slug }));
}

export const dynamicParams = false;

export default function CategoryPage({ params }: { params: { category: string } }) {
  const category = getCategory(params.category);
  if (!category) notFound();

  const docs = getDocsForCategory(category.slug);

  return (
    <main className="wrap">
      <Link href="/" className="crumb">
        ← All sections
      </Link>
      <header className="category-head">
        <span className="eyebrow">Section {category.code}</span>
        <h1>{category.label}</h1>
        <p>{category.description}</p>
      </header>

      {docs.length === 0 ? (
        <p className="empty">Nothing filed here yet.</p>
      ) : (
        <div className="doc-list">
          {docs.map((doc) => (
            <Link key={doc.slug} href={`/${category.slug}/${doc.slug}`} className="doc-row">
              <div className="doc-row-title">{doc.title}</div>
              {doc.summary && <div className="doc-row-summary">{doc.summary}</div>}
              {doc.date && <span className="doc-row-meta">{doc.date}</span>}
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
