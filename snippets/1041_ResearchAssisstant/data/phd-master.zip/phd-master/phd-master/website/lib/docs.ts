import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import remarkRehype from 'remark-rehype';
import rehypeKatex from 'rehype-katex';
import rehypeStringify from 'rehype-stringify';

// The repo's canonical folders live one level above this `website/` app.
const REPO_ROOT = path.join(process.cwd(), '..');

export type Category = {
  slug: string;
  code: string;
  label: string;
  description: string;
};

// Order and labels follow PROJECT_GUIDE.md §1. Numbering is meaningful here
// (it's the repo's actual folder sequence), so it's shown as part of the UI.
export const CATEGORIES: Category[] = [
  { slug: '00_INBOX', code: '00', label: 'Inbox', description: 'Unclassified material awaiting review.' },
  { slug: '01_PROJECT', code: '01', label: 'Project', description: 'Research objectives, scope, roadmap, and the doctoral plan.' },
  { slug: '02_LITERATURE', code: '02', label: 'Literature', description: 'Theoretical foundations and related work.' },
  { slug: '03_SOFTWARE', code: '03', label: 'Software', description: 'Software architecture and implementation details.' },
  { slug: '04_HARDWARE', code: '04', label: 'Hardware', description: 'Hardware architecture and implementation details.' },
  { slug: '05_EXPERIMENTS', code: '05', label: 'Experiments', description: 'Evaluation protocols, planned and run.' },
  { slug: '06_FIELD_NOTES', code: '06', label: 'Field Notes', description: 'Observations from fieldwork and site visits.' },
  { slug: '07_MEETINGS', code: '07', label: 'Meetings', description: 'Supervision and research meeting records.' },
  { slug: '08_DECISIONS', code: '08', label: 'Decisions', description: 'Durable project decisions and their rationale.' },
  { slug: '09_MEDIA', code: '09', label: 'Media', description: 'Diagrams, images, and visual references.' },
  { slug: '10_PUBLICATIONS', code: '10', label: 'Publications', description: 'Authored and co-authored papers arising from this research.' },
];

export function getCategory(slug: string): Category | undefined {
  return CATEGORIES.find((c) => c.slug === slug);
}

export type DocMeta = {
  slug: string;
  filename: string;
  categorySlug: string;
  title: string;
  summary?: string;
  date?: string;
};

function readMarkdownFiles(categorySlug: string): { filename: string; raw: string }[] {
  const dir = path.join(REPO_ROOT, categorySlug);
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.toLowerCase().endsWith('.md'))
    .map((filename) => ({ filename, raw: fs.readFileSync(path.join(dir, filename), 'utf8') }));
}

// YAML parses an unquoted date like `2026-09-13` into a real JS Date object,
// not a string. If that Date object is ever rendered directly in JSX or used
// where a string is expected, React throws "Objects are not valid as a React
// child". Normalize it to a plain YYYY-MM-DD string here, once, so nothing
// downstream ever has to think about it again.
function toDateString(value: unknown): string | undefined {
  if (!value) return undefined;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return String(value);
}

// A document is public unless its frontmatter explicitly sets `public: false`.
// Used for material that should stay in the repo for the researcher's own
// reference (e.g. full copies of third-party copyrighted papers) but never
// get built into a publicly-servable page.
function isPublic(data: Record<string, unknown>): boolean {
  return data.public !== false;
}

function metaFromRaw(categorySlug: string, filename: string, raw: string): DocMeta {
  const { data } = matter(raw);
  const fallbackSlug = filename.replace(/\.md$/i, '');
  return {
    slug: (data.slug as string) || fallbackSlug,
    filename,
    categorySlug,
    title: (data.title as string) || fallbackSlug,
    summary: data.summary as string | undefined,
    date: toDateString(data.date),
  };
}

export function getDocsForCategory(categorySlug: string): DocMeta[] {
  return readMarkdownFiles(categorySlug)
    .filter(({ raw }) => isPublic(matter(raw).data))
    .map(({ filename, raw }) => metaFromRaw(categorySlug, filename, raw))
    .sort((a, b) => (a.date && b.date ? (a.date < b.date ? 1 : -1) : a.title.localeCompare(b.title)));
}

export function getAllDocs(): DocMeta[] {
  return CATEGORIES.flatMap((c) => getDocsForCategory(c.slug));
}

export type DocContent = DocMeta & { html: string };

// remark-math marks $inline$ and $$block$$ spans as math nodes; remark-rehype
// hands those to rehype-katex, which renders them into the actual typeset
// HTML/MathML KaTeX needs (the matching KaTeX stylesheet is loaded once, in
// the root layout, rather than per-document).
//
// Docs also legitimately contain plain dollar amounts ("$150-200/month",
// "$9.44 million") that remark-math will try to read as the start of an
// inline-math span. By default rehype-katex THROWS on anything it can't
// parse as valid LaTeX, which would crash the entire page (and, transitively,
// the whole `next build`) over a stray dollar sign that was never meant to be
// math. `throwOnError: false` makes it render the offending span as plain
// text (in red, so a real formula typo is still visible) instead of failing
// the build; `strict: false` silences KaTeX's warnings for the same class of
// "technically not standard LaTeX but not actually a formula either" input.
const markdownToHtml = unified()
  .use(remarkParse)
  .use(remarkGfm)
  .use(remarkMath)
  .use(remarkRehype, { allowDangerousHtml: true })
  .use(rehypeKatex, { throwOnError: false, strict: false })
  .use(rehypeStringify, { allowDangerousHtml: true });

export async function getDocContent(categorySlug: string, slug: string): Promise<DocContent | null> {
  const files = readMarkdownFiles(categorySlug);
  const match = files.find(({ filename, raw }) => {
    const meta = metaFromRaw(categorySlug, filename, raw);
    return meta.slug === slug;
  });
  if (!match) return null;
  const { data, content } = matter(match.raw);
  // Defense in depth: even if a non-public slug were somehow requested,
  // refuse to render it. generateStaticParams (which drives what actually
  // gets built for `output: 'export'`) already excludes these via
  // getDocsForCategory, so in practice this path never gets hit - but it's
  // a one-line guard against ever serving something that shouldn't be public.
  if (!isPublic(data)) return null;
  const meta = metaFromRaw(categorySlug, match.filename, match.raw);
  try {
    const processed = await markdownToHtml.process(content);
    return { ...meta, html: processed.toString() };
  } catch (err) {
    // Last-resort fallback: if the full markdown+math+GFM pipeline still
    // throws on some unanticipated input, don't take the whole build down
    // over one document - fall back to plain-escaped text so the page still
    // builds and is readable, and log which document/why for follow-up.
    console.error(`[docs] Failed to render ${categorySlug}/${match.filename}:`, err);
    const escaped = content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    return { ...meta, html: `<pre>${escaped}</pre>` };
  }
}
