/** @type {import('next').NextConfig} */
const nextConfig = {
  // Static export: every page is pre-rendered at build time by reading the
  // markdown files that live one level up in the repo (../00_INBOX, ../01_PROJECT, ...).
  // This means the whole site is just HTML/CSS/JS with no server runtime needed,
  // which is what lets Vercel deploy it straight from this folder.
  output: 'export',
};

export default nextConfig;
