# PhD research site

A static site that turns the canonical folders in this repository (`01_PROJECT`,
`02_LITERATURE`, `03_SOFTWARE`, ... `10_PUBLICATIONS`) into a browsable
website: one index page, one page per category, one page per document.
No database, no CMS — it reads the markdown files and their frontmatter
(`title`, `summary`, `date`, `slug`) directly from the repo at build time.

## Deploying on Vercel (ready to go)

1. On [vercel.com](https://vercel.com), **Add New → Project** and import this
   GitHub repo (`tamasdongo/phd`).
2. When the import screen asks for the **Root Directory**, click *Edit* and
   set it to `website`. (Vercel still checks out the whole repository during
   the build, so the site can read the markdown folders sitting next to this
   one — setting the root directory just tells Vercel where to run `next build`.)
3. Framework Preset: **Next.js** (auto-detected once the root directory is set;
   `website/vercel.json` also pins this explicitly). No environment variables
   are needed.
4. Click **Deploy**. Every subsequent push to `master` that touches a markdown
   file will trigger a fresh build and the new content will appear automatically
   — no site code changes needed.

## Local development

```bash
cd website
npm install
npm run dev
```

Open http://localhost:3000. Because the site reads `../00_INBOX` etc. relative
to this folder, run it from inside a checkout of the full repo, not a copy of
just the `website` folder.

## Adding a new document

Nothing to configure here — add a markdown file with the usual frontmatter
(see `PROJECT_GUIDE.md` §12.1) to any of the numbered folders, and it appears
on the site's next build.
