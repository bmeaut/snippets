# Deployment Guide

This guide covers deploying the PhD Research Assistant MCP service to a small cloud host so you can access it from your phone anywhere.

## Overview

The service runs as a simple FastAPI application in Docker. Recommended hosts:
- **Render.com** (free tier available, straightforward dashboard)
- **Fly.io** (generous free tier, fast global deployment)
- **Railway.app** (simple, pay-as-you-go)

The service is stateless except for:
- GitHub API calls (requires `GITHUB_TOKEN` and `GITHUB_REPO` as env vars)
- LangGraph orchestration (either in-process mock, local HTTP mock, or hosted endpoint)
- Persistent checkpoints/audit logs (stored in container `logs/` and `.langgraph/` — can be retained via volume mounts in production)

## Prerequisites

1. A GitHub repository for your PhD project
2. A GitHub API token with repo read+write scope (or a GitHub App)
3. (Optional) A hosted LangGraph endpoint, or use the in-process mock

## Deployment: Render.com

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "PhD Research Assistant MCP service"
git remote add origin https://github.com/YOUR_USERNAME/phd-research-assistant.git
git push -u origin main
```

### 2. Create Render Service

1. Go to https://render.com/dashboard
2. Click **New +** → **Web Service**
3. Select your GitHub repo
4. Configure:
   - **Name**: `phd-research-assistant`
   - **Runtime**: Docker
   - **Build Command**: (leave empty, uses Dockerfile)
   - **Start Command**: (leave empty, uses Dockerfile CMD)
   - **Instance Type**: Free (0.5 CPU, 0.5 GB RAM) or Starter ($7/month for 1 CPU, 1 GB RAM)

### 3. Set Environment Variables

In the Render dashboard, add the following environment variables to the service:

```
GITHUB_TOKEN=ghp_YOUR_GITHUB_API_TOKEN
GITHUB_REPO=your-username/your-phd-repo
MOCK_LANGGRAPH=1
PORT=8000
```

Or if using a hosted LangGraph:
```
GITHUB_TOKEN=ghp_YOUR_GITHUB_API_TOKEN
GITHUB_REPO=your-username/your-phd-repo
LANGGRAPH_URL=https://your-langgraph-host/api
LANGGRAPH_API_KEY=your-api-key
PORT=8000
```

### 4. Deploy

Click **Deploy** and wait for the build to complete. Render will assign you a public URL like:
```
https://phd-research-assistant.onrender.com
```

### 5. Verify

```bash
curl https://phd-research-assistant.onrender.com/health
# should return: {"status":"ok"}

curl -X POST https://phd-research-assistant.onrender.com/mcp/get_project_context \
  -H "Content-Type: application/json"
# should return project context
```

## Deployment: Fly.io

### 1. Install Fly CLI

```bash
# macOS
brew install flyctl

# Windows (with Powershell)
pwsh -Command "iwr https://fly.io/install.ps1 -useb | iex"

# Linux
curl -L https://fly.io/install.sh | sh
```

### 2. Login and Create App

```bash
flyctl auth login
flyctl launch
# Answer prompts:
# - App name: phd-research-assistant
# - Region: choose closest to you
# - PostgreSQL: no
# - Redis: no
```

This creates `fly.toml` in your workspace.

### 3. Set Secrets

```bash
flyctl secrets set GITHUB_TOKEN=ghp_YOUR_GITHUB_API_TOKEN
flyctl secrets set GITHUB_REPO=your-username/your-phd-repo
flyctl secrets set MOCK_LANGGRAPH=1
```

### 4. Deploy

```bash
flyctl deploy
```

Fly will build the image and deploy. You'll get a public URL like:
```
https://phd-research-assistant.fly.dev
```

### 5. Monitor

```bash
flyctl logs
```

## Environment Variables Reference

| Variable | Required | Example | Notes |
|----------|----------|---------|-------|
| `GITHUB_TOKEN` | Yes | `ghp_xxxx` | PAT with repo scope or GitHub App token |
| `GITHUB_REPO` | Yes | `owner/repository` | Your PhD project repo |
| `MOCK_LANGGRAPH` | No | `1` | Use in-process mock (default) |
| `LANGGRAPH_URL` | No | `https://...` | Hosted LangGraph endpoint (if not using mock) |
| `LANGGRAPH_API_KEY` | No | `...` | Bearer token for LangGraph endpoint |
| `PORT` | No | `8000` | Port (Render/Fly set automatically) |

## Accessing from Your Phone

1. Get your deployed service URL (e.g., `https://phd-research-assistant.onrender.com`)
2. Use any HTTP client on your phone:
   - **Postman** (mobile app)
   - **Thunder Client** (mobile)
   - **Custom client** pointing to your MCP endpoints

3. Example workflow:
   ```
   POST /mcp/start_thread
   body: {"name":"morning-session"}
   
   POST /mcp/plan_changes
   body: {"thread_id":"...", "instruction":"Update camera mount design"}
   
   POST /mcp/propose_changes
   body: {"branch_name":null, "summary":"Design update", ...}
   
   POST /mcp/create_pull_request
   body: {"branch":"...", "title":"Design change", ...}
   ```

4. Or integrate with **Claude mobile** if you set up MCP bridge/gateway (advanced).

## Persistent State

By default, the service stores:
- **Logs**: `logs/audit.log` (JSON-lines audit trail)
- **LangGraph checkpoints**: `.langgraph/thread_*.json`

These are ephemeral in the container. To persist them:

### Render.com

- Add a **Persistent Disk** to your service (paid feature)
- Mount at `/app/.langgraph` and `/app/logs`

### Fly.io

- Add a volume to `fly.toml`:
  ```toml
  [[mounts]]
  source = "phd_data"
  destination = "/app/.langgraph"
  
  [[mounts]]
  source = "phd_logs"
  destination = "/app/logs"
  ```
- Run: `flyctl volumes create phd_data phd_logs`

## Troubleshooting

### Service won't start

Check logs:
- **Render**: Dashboard → Logs
- **Fly.io**: `flyctl logs`

Common issues:
- Missing `GITHUB_TOKEN` or `GITHUB_REPO` env vars
- GitHub token doesn't have repo access
- LangGraph endpoint unreachable

### 404 on root path

This is normal. The root path has no handler. Use `/health` or `/docs` (Swagger UI).

### GitHub operations fail

Verify:
- Token is valid: `curl -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user`
- Repo is accessible: `curl -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/repos/owner/repo`
- Token has `repo` scope

## Security Notes

- Store `GITHUB_TOKEN` and `LANGGRAPH_API_KEY` as secrets, never commit to git
- Use GitHub App tokens (app-to-repo) instead of personal tokens for better isolation
- Consider adding endpoint authentication (see TODO: endpoint auth)
- Audit logs are stored; regularly export and archive them

## Next Steps

- Add endpoint authentication (API key per client)
- Set up monitoring and alerts
- Add a database for persistent state (optional, for large scale)
- Integrate with Claude via MCP bridge (for phone native experience)

