"""Run the local LangGraph mock server for development.

Usage:
    python run_local_langgraph.py

Environment:
    LANGGRAPH_MOCK_PORT - optional port (default 9001)
"""
import os
import uvicorn

if __name__ == "__main__":
    port = int(os.getenv("LANGGRAPH_MOCK_PORT", "9001"))
    uvicorn.run("app.langgraph_local_server:app", host="127.0.0.1", port=port, reload=True)
