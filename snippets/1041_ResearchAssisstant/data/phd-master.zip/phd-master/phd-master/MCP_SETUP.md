# Adding MCP Server to Claude Desktop

Your PhD Research Assistant MCP server is ready to connect to Claude desktop.

## Setup

### 1. Edit Claude Desktop Config

On Windows, open:
```
C:\Users\<YourUsername>\AppData\Roaming\Claude\claude_desktop_config.json
```

Add this MCP server config (merge with existing config if you have one):

```json
{
  "mcpServers": {
    "phd-research-assistant": {
      "command": "C:\\Users\\Tamas\\Desktop\\PhD\\AI EDIH\\1041_ResearchAssisstant\\.venv\\Scripts\\python.exe",
      "args": [
        "C:\\Users\\Tamas\\Desktop\\PhD\\AI EDIH\\1041_ResearchAssisstant\\mcp_run.py"
      ],
      "env": {
        "PHDA_API_URL": "https://phd-l3gd.onrender.com"
      }
    }
  }
}
```

### 2. Restart Claude Desktop

Fully close and reopen Claude desktop app. It should connect to the MCP server.

### 3. Use the Tools

In Claude, you should now see 9 tools available:
- `get_project_context` — Fetch repo info and README
- `list_directory` — List files and subdirectories at a path (optional recursion and branch)
- `get_file_content` — Fetch raw text content of a file at a path and branch
- `delete_file` — Delete a file on a non-default feature branch
- `start_thread` — Start a research thread
- `plan_changes` — Plan file modifications
- `propose_changes` — Create a branch with changes
- `get_diff` — View diff for a branch
- `create_pull_request` — Create a PR to merge the branch (idempotent, returns existing PR info if already open)



## Security Warning ⚠️

Your current Render service at `https://phd-l3gd.onrender.com` is **publicly accessible without authentication**.

Before using this in production, you should:
1. Add API key authentication to the FastAPI app
2. Set `PHDA_API_KEY` environment variable on Render
3. Pass the key in Claude config

## Troubleshooting

If Claude says "Failed to connect to MCP server":

1. Check MCP server runs locally:
   ```
   python mcp_run.py
   ```
   (It should start and wait for connections)

2. Verify `PHDA_API_URL` is correct and accessible from your machine

3. Check Claude logs:
   - On Windows: `%APPDATA%\Claude\logs\`

## For Phone Access

Claude desktop on a phone cannot directly connect to MCP servers via stdio (they only support local connections). To use this from your phone:

1. **Option A**: Use Claude web app + custom tool integration (requires more setup)
2. **Option B**: Keep using the REST API directly (less elegant but works)
3. **Option C**: Set up an SSH tunnel to your machine and run MCP server there

The MCP approach is best for desktop; for phone access consider the REST API or a web interface instead.
