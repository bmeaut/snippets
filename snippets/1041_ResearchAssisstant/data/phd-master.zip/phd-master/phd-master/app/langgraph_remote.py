import os
from typing import Optional, Dict, Any, List
import httpx
import logging

logger = logging.getLogger("langgraph_remote")


class RemoteLangGraphManager:
    """Minimal remote LangGraph client to a hosted orchestration endpoint.

    Expected endpoints (MVP contract):
    - POST {base_url}/threads  -> create thread, returns JSON {thread_id, ...}
    - GET  {base_url}/threads/{thread_id} -> get thread state
    - POST {base_url}/threads/{thread_id}/checkpoint -> accept JSON state
    - POST {base_url}/threads/{thread_id}/plan -> body {instruction} returns proposed changes

    These are simple conventions — adapt when the hosted service provides actual API docs.
    """

    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, gh_client=None):
        self.base_url = base_url or os.getenv("LANGGRAPH_URL")
        self.api_key = api_key or os.getenv("LANGGRAPH_API_KEY")
        self.gh = gh_client
        if self.base_url and self.base_url.endswith("/"):
            self.base_url = self.base_url[:-1]

    def _headers(self) -> Dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def create_thread(self, name: Optional[str] = None, initial_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}/threads"
        body = {"name": name, "context": initial_context}
        try:
            r = httpx.post(url, json=body, headers=self._headers(), timeout=10.0)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.exception("failed to create remote thread: %s", e)
            raise

    def get_thread(self, thread_id: str) -> Optional[Dict[str, Any]]:
        url = f"{self.base_url}/threads/{thread_id}"
        try:
            r = httpx.get(url, headers=self._headers(), timeout=10.0)
            if r.status_code == 404:
                return None
            r.raise_for_status()
            return r.json()
        except Exception:
            logger.exception("failed to fetch remote thread %s", thread_id)
            return None

    def checkpoint(self, thread_id: str, state: Dict[str, Any]) -> bool:
        url = f"{self.base_url}/threads/{thread_id}/checkpoint"
        try:
            r = httpx.post(url, json={"state": state}, headers=self._headers(), timeout=10.0)
            r.raise_for_status()
            return True
        except Exception:
            logger.exception("failed to checkpoint remote thread %s", thread_id)
            return False

    def plan_changes(self, thread_id: str, instruction: str) -> List[Dict[str, str]]:
        url = f"{self.base_url}/threads/{thread_id}/plan"
        try:
            r = httpx.post(url, json={"instruction": instruction}, headers=self._headers(), timeout=30.0)
            r.raise_for_status()
            return r.json().get("proposals", [])
        except Exception:
            logger.exception("failed to request plan for thread %s", thread_id)
            return []
