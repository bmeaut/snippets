from typing import Optional, Dict, Any, List
from datetime import datetime, timezone
import uuid
import logging

logger = logging.getLogger("langgraph_mock")


class MockLangGraphManager:
    """In-process mock LangGraph manager for local development and tests.

    This implements the same methods used by the real remote manager so the
    adapter can return it when `MOCK_LANGGRAPH=1`.
    """

    def __init__(self, gh_client=None):
        self.gh = gh_client
        self.threads: Dict[str, Dict[str, Any]] = {}

    def create_thread(self, name: Optional[str] = None, initial_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        tid = uuid.uuid4().hex[:12]
        data = {
            "thread_id": tid,
            "name": name or f"mock-{tid}",
            "created": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "context": initial_context or {},
            "history": [],
            "checkpoints": [],
        }
        self.threads[tid] = data
        return data

    def get_thread(self, thread_id: str) -> Optional[Dict[str, Any]]:
        return self.threads.get(thread_id)

    def checkpoint(self, thread_id: str, state: Dict[str, Any]) -> bool:
        t = self.threads.get(thread_id)
        if not t:
            return False
        t.setdefault("checkpoints", []).append({"ts": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), "state": state})
        return True

    def plan_changes(self, thread_id: str, instruction: str) -> List[Dict[str, str]]:
        # Very small heuristic: if PROJECT_GUIDE.md exists, append there, else create decision file
        proposals: List[Dict[str, str]] = []
        guide = None
        if self.gh:
            guide = self.gh.get_file("PROJECT_GUIDE.md")
        if guide is not None:
            new_content = guide + "\n\n" + f"## Proposed note ({datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')}):\n{instruction}\n"
            proposals.append({"path": "PROJECT_GUIDE.md", "content": new_content})
        else:
            fname = f"08_DECISIONS/decision_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}.md"
            content = f"# Decision created from conversation {thread_id}\n\n{instruction}\n"
            proposals.append({"path": fname, "content": content})

        # record a checkpoint
        self.checkpoint(thread_id, {"planned_changes": proposals, "instruction": instruction})
        return proposals
