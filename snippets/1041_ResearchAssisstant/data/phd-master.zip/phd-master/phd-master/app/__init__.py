"""Application package for the PhD research assistant."""
