import os
from typing import Optional
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from .github_client import GitHubClient
from .schemas import FileRequest, FileResponse, ProjectContextResponse, CommitSummary
from .schemas import (
    ProposeChangesRequest,
    ProposeChangesResponse,
    DiffResponse,
    DiffFile,
    CreatePRRequest,
    CreatePRResponse,
    StartThreadRequest,
    StartThreadResponse,
    PlanRequest,
    PlanResponse,
    DirectoryEntry,
    ListDirectoryRequest,
    ListDirectoryResponse,
    GetFileContentRequest,
    GetFileContentResponse,
    DeleteFileRequest,
    DeleteFileResponse,
)
from datetime import datetime, timezone
import logging
import json

logger = logging.getLogger("phd_assistant")
logging.basicConfig(level=logging.INFO)


def ensure_logs_dir():
    d = os.path.join(os.getcwd(), "logs")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def audit_log(event: dict):
    """Write a JSON-lines audit entry"""
    d = ensure_logs_dir()
    p = os.path.join(d, "audit.log")
    entry = {"ts": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), **event}
    try:
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        logger.exception("audit log failed")


load_dotenv()

app = FastAPI(title="PhD Research Assistant")

def get_gh_client() -> GitHubClient:
    global gh_client
    if gh_client is None:
        gh_client = GitHubClient()
        return gh_client

    current = GitHubClient()
    if (
        current.local_path != gh_client.local_path
        or current.repo_full_name != gh_client.repo_full_name
        or current.token != getattr(gh_client, "token", None)
    ):
        gh_client.token = current.token
        gh_client.local_path = current.local_path
        gh_client.repo_full_name = current.repo_full_name
        if current.token:
            gh_client.gh = GitHubClient(current.token).gh
        else:
            gh_client.gh = None
        try:
            gh_client.repo = gh_client.gh.get_repo(gh_client.repo_full_name) if gh_client.gh and gh_client.repo_full_name else None
        except Exception:
            gh_client.repo = None
    return gh_client


gh_client = GitHubClient()
from .langgraph_adapter import get_manager
lg = get_manager(gh_client=gh_client)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/mcp/get_file", response_model=FileResponse)
def mcp_get_file(req: FileRequest):
    client = get_gh_client()
    content = client.get_file(req.path)
    if content is None:
        raise HTTPException(status_code=404, detail="file not found")
    return FileResponse(path=req.path, content=content)


@app.post("/mcp/get_project_context", response_model=ProjectContextResponse)
def mcp_get_project_context():
    client = get_gh_client()
    repo = client.repo_full_name or "local"
    top = client.list_top_level()
    readme = client.get_file("README.md")
    guide = client.get_file("PROJECT_GUIDE.md")
    commits = []
    for c in client.recent_commits(5):
        commits.append(CommitSummary(sha=c.get("sha"), message=c.get("message"), author=c.get("author")))
    return ProjectContextResponse(repo=repo, top_level=top, readme=readme, project_guide=guide, recent_commits=commits)


@app.post("/mcp/start_thread", response_model=StartThreadResponse)
def mcp_start_thread(req: StartThreadRequest):
    client = get_gh_client()
    ctx = {
        "repo": client.repo_full_name,
        "top_level": client.list_top_level(),
        "project_guide_exists": bool(client.get_file("PROJECT_GUIDE.md")),
    }
    t = lg.create_thread(name=req.name, initial_context=ctx)
    audit_log({"tool": "start_thread", "thread_id": t.get("thread_id"), "name": t.get("name"), "repo": client.repo_full_name})
    return StartThreadResponse(thread_id=t.get("thread_id"), name=t.get("name"))


@app.get("/mcp/get_thread")
def mcp_get_thread(thread_id: str):
    t = lg.get_thread(thread_id)
    if t is None:
        raise HTTPException(status_code=404, detail="thread not found")
    return t


@app.post("/mcp/checkpoint")
def mcp_checkpoint(thread_id: str, state: dict):
    ok = lg.checkpoint(thread_id, state)
    if not ok:
        raise HTTPException(status_code=404, detail="thread not found")
    audit_log({"tool": "checkpoint", "thread_id": thread_id})
    return {"status": "ok"}


@app.post("/mcp/plan_changes", response_model=PlanResponse)
def mcp_plan_changes(req: PlanRequest):
    t = lg.get_thread(req.thread_id)
    if t is None:
        raise HTTPException(status_code=404, detail="thread not found")
    proposals = lg.plan_changes(req.thread_id, req.instruction)
    changes = [{"path": p.get("path"), "content": p.get("content")} for p in proposals]
    audit_log({"tool": "plan_changes", "thread_id": req.thread_id, "num_changes": len(changes)})
    return PlanResponse(thread_id=req.thread_id, proposed_changes=changes, summary=f"Proposed {len(changes)} change(s)")


@app.post("/mcp/propose_changes", response_model=ProposeChangesResponse)
def mcp_propose_changes(req: ProposeChangesRequest):
    client = get_gh_client()
    branch = req.branch_name or f"assistant/proposal-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    created = client.create_branch(branch)
    if created is None:
        raise HTTPException(status_code=500, detail="failed to create branch")
    changed = client.update_or_create_files(branch, [c.model_dump() for c in req.changes], commit_message=req.summary or "assistant: propose changes")
    logger.info("propose_changes: conversation=%s branch=%s files=%s", req.conversation_id, branch, changed)
    audit_log({"conversation_id": req.conversation_id, "tool": "propose_changes", "repo": client.repo_full_name, "branch": branch, "files_changed": changed})
    return ProposeChangesResponse(branch=branch, files_changed=changed, message="proposed")


@app.post("/mcp/get_diff", response_model=DiffResponse)
def mcp_get_diff(branch: str):
    client = get_gh_client()
    diff = client.get_branch_diff(branch)
    if diff is None:
        raise HTTPException(status_code=404, detail="diff not available")
    files = []
    for f in diff.get("files", []):
        files.append(DiffFile(filename=f.get("filename"), status=f.get("status"), additions=f.get("additions"), deletions=f.get("deletions"), patch=f.get("patch")))
    return DiffResponse(branch=diff.get("branch"), base=diff.get("base"), files=files)


@app.post("/mcp/create_pull_request", response_model=CreatePRResponse)
def mcp_create_pull_request(req: CreatePRRequest):
    client = get_gh_client()
    base_branch = req.base or client.default_branch or "master"
    try:
        pr = client.create_pull_request(req.title, req.description or "", req.branch, base=base_branch)
        if pr is None:
            raise HTTPException(
                status_code=400,
                detail=f"Failed to create pull request from branch '{req.branch}' to '{base_branch}'."
            )
        logger.info("create_pr: branch=%s pr=%s already_existed=%s", req.branch, pr.get("url"), pr.get("already_existed", False))
        audit_log({"tool": "create_pull_request", "repo": client.repo_full_name, "branch": req.branch, "pr_url": pr.get("url"), "pr_number": pr.get("number"), "already_existed": pr.get("already_existed", False)})
        return CreatePRResponse(
            url=pr.get("url"),
            number=pr.get("number"),
            title=pr.get("title"),
            already_existed=pr.get("already_existed", False)
        )
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"mcp_create_pull_request failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"mcp_create_pull_request failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Failed to create pull request: {str(e)}")


@app.post("/mcp/delete_file", response_model=DeleteFileResponse)
def mcp_delete_file(req: DeleteFileRequest):
    client = get_gh_client()
    default_branch = client.default_branch or "master"
    target_branch = (req.branch or "").strip()
    if not target_branch or target_branch.lower() == default_branch.lower():
        raise HTTPException(
            status_code=400,
            detail=f"Deleting files directly on default branch '{default_branch}' is not allowed. Please specify a non-default feature branch."
        )
    try:
        res = client.delete_file(path=req.path, branch=target_branch, message=req.message)
        audit_log({"tool": "delete_file", "path": req.path, "branch": target_branch, "sha": res.get("sha")})
        return DeleteFileResponse(path=res["path"], branch=res["branch"], deleted=True, sha=res["sha"])
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"mcp_delete_file failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Failed to delete file: {str(e)}")



@app.post("/mcp/list_directory", response_model=ListDirectoryResponse)
def mcp_list_directory(req: Optional[ListDirectoryRequest] = None):
    client = get_gh_client()
    req_path = req.path if req and req.path is not None else ""
    req_recursive = req.recursive if req and req.recursive is not None else False
    req_branch = req.branch if req and req.branch else "master"
    try:
        res = client.list_directory(path=req_path, recursive=req_recursive, branch=req_branch)
        entries = [DirectoryEntry(name=e["name"], type=e["type"], path=e["path"]) for e in res.get("entries", [])]
        audit_log({"tool": "list_directory", "path": req_path, "recursive": req_recursive, "branch": req_branch, "count": len(entries)})
        return ListDirectoryResponse(path=res.get("path", req_path), entries=entries)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"mcp_list_directory failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Failed to list directory: {str(e)}")


@app.post("/mcp/get_file_content", response_model=GetFileContentResponse)
def mcp_get_file_content(req: GetFileContentRequest):
    client = get_gh_client()
    req_branch = req.branch or "master"
    try:
        res = client.get_file_content(path=req.path, branch=req_branch)
        audit_log({"tool": "get_file_content", "path": req.path, "branch": req_branch})
        return GetFileContentResponse(path=res["path"], branch=res["branch"], content=res["content"], sha=res["sha"])
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"mcp_get_file_content failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Failed to fetch file content: {str(e)}")



# ===== Remote MCP HTTP/SSE & OAuth Discovery Endpoints =====
from fastapi.responses import RedirectResponse
from .http_mcp_server import mcp as http_mcp
from mcp.server.transport_security import TransportSecuritySettings

SERVER_URL = os.getenv("SERVER_BASE_URL", "https://phd-l3gd.onrender.com")


@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info("HTTP Request: %s %s", request.method, request.url.path)
    return await call_next(request)


@app.get("/.well-known/oauth-authorization-server")
@app.get("/.well-known/oauth-authorization-server/")
def oauth_metadata():
    return {
        "issuer": SERVER_URL,
        "authorization_endpoint": f"{SERVER_URL}/oauth/authorize",
        "token_endpoint": f"{SERVER_URL}/oauth/token",
        "registration_endpoint": f"{SERVER_URL}/oauth/register",
        "response_types_supported": ["code"],
        "grant_types_supported": ["authorization_code"],
        "code_challenge_methods_supported": ["S256", "plain"],
    }


@app.get("/.well-known/oauth-protected-resource")
@app.get("/.well-known/oauth-protected-resource/")
def oauth_protected_resource():
    return {
        "resource": SERVER_URL,
        "authorization_servers": [SERVER_URL],
        "scopes_supported": ["read", "write"],
    }


@app.post("/oauth/register")
async def oauth_register(request: Request):
    try:
        data = await request.json()
    except Exception:
        data = {}
    return {
        "client_id": "phd-mcp-client-id",
        "client_secret": "phd-mcp-client-secret",
        "client_name": data.get("client_name", "Claude"),
        "redirect_uris": data.get("redirect_uris", []),
        "grant_types": ["authorization_code"],
        "response_types": ["code"],
    }


@app.get("/oauth/authorize")
def oauth_authorize(redirect_uri: str = "", state: str = ""):
    if redirect_uri:
        sep = "&" if "?" in redirect_uri else "?"
        target = f"{redirect_uri}{sep}code=phd-auto-code&state={state}"
        return RedirectResponse(url=target, status_code=302)
    return {"status": "authorized", "code": "phd-auto-code"}


@app.post("/oauth/token")
def oauth_token():
    return {
        "access_token": "phd-auto-access-token",
        "token_type": "Bearer",
        "expires_in": 86400,
    }


sec = TransportSecuritySettings(enable_dns_rebinding_protection=False)
app.mount("/mcp_sse", http_mcp.sse_app(transport_security=sec))
app.mount("/sse", http_mcp.sse_app(transport_security=sec))



