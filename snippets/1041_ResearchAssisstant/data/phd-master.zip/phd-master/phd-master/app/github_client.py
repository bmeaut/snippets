import os
from typing import Optional, List
from github import Github, Auth


class GitHubClient:
    def __init__(self, token: Optional[str] = None, repo_full_name: Optional[str] = None, local_path: Optional[str] = None):
        self.token = token or os.getenv("GITHUB_TOKEN")
        self.local_path = local_path or os.getenv("LOCAL_REPO_PATH")
        self.repo_full_name = repo_full_name or os.getenv("GITHUB_REPO")
        if self.token:
            self.gh = Github(auth=Auth.Token(self.token))
        else:
            self.gh = None

        self.repo = None
        self.default_branch = os.getenv("GITHUB_DEFAULT_BRANCH") or "master"
        if self.gh and self.repo_full_name:
            try:
                self.repo = self.gh.get_repo(self.repo_full_name)
                self.default_branch = getattr(self.repo, "default_branch", None) or self.default_branch
            except Exception:
                # Fall back to local file access when the configured repo is not
                # available (e.g. missing repo, invalid credentials, or CI/test env).
                self.repo = None

    def get_file(self, path: str) -> Optional[str]:
        if self.repo:
            try:
                content = self.repo.get_contents(path)
                return content.decoded_content.decode("utf-8")
            except Exception:
                return None
        # local fallback
        if self.local_path:
            p = os.path.join(self.local_path, path)
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return f.read()
            except Exception:
                return None
        return None

    def list_top_level(self) -> List[str]:
        if self.repo:
            try:
                return [c.path for c in self.repo.get_contents("")]
            except Exception:
                return []
        if self.local_path:
            try:
                return sorted([n for n in os.listdir(self.local_path)])
            except Exception:
                return []
        return []

    def recent_commits(self, n: int = 5):
        out = []
        if self.repo:
            try:
                for c in self.repo.get_commits()[:n]:
                    out.append({"sha": c.sha, "message": c.commit.message, "author": c.commit.author.name if c.commit.author else None})
            except Exception:
                pass
        return out

    def search_repository(self, query: str, max_results: int = 20) -> List[dict]:
        """Naive repository search: looks for query terms inside text files and returns matching paths and snippets.
        Falls back to local repo scanning when GitHub API not available or on failure.
        """
        terms = [t.strip().lower() for t in query.split() if t.strip()]
        results: List[dict] = []

        def scan_contents(contents, base_path=""):
            for c in contents:
                if c.type == "dir":
                    try:
                        scan_contents(self.repo.get_contents(c.path), c.path)
                    except Exception:
                        continue
                else:
                    try:
                        if c.size > 200000:
                            continue
                        text = c.decoded_content.decode("utf-8", errors="ignore").lower()
                        score = sum(1 for t in terms if t in text)
                        if score > 0:
                            snippet = None
                            idx = text.find(terms[0]) if terms else -1
                            if idx >= 0:
                                start = max(0, idx - 80)
                                snippet = text[start:start+200]
                            results.append({"path": c.path, "score": score, "snippet": snippet})
                            if len(results) >= max_results:
                                return
                    except Exception:
                        continue

        # Try GitHub API
        if self.repo:
            try:
                root = self.repo.get_contents("")
                scan_contents(root)
            except Exception:
                pass

        # Local fallback: walk filesystem
        if self.local_path and len(results) < max_results:
            for root, dirs, files in os.walk(self.local_path):
                for fn in files:
                    if fn.lower().endswith(('.md', '.txt', '.rst', '.py')):
                        p = os.path.join(root, fn)
                        try:
                            with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                                text = f.read().lower()
                            score = sum(1 for t in terms if t in text)
                            if score > 0:
                                rel = os.path.relpath(p, self.local_path).replace('\\', '/')
                                results.append({"path": rel, "score": score, "snippet": None})
                                if len(results) >= max_results:
                                    break
                        except Exception:
                            continue
                if len(results) >= max_results:
                    break

        results.sort(key=lambda r: r.get('score', 0), reverse=True)
        return results

    def create_branch(self, branch_name: str, base: Optional[str] = None) -> Optional[str]:
        if not self.repo:
            return None
        base_branch = (base or self.default_branch or "master")
        ref = f"refs/heads/{branch_name}"
        try:
            sb = self.repo.get_branch(base_branch)
            self.repo.create_git_ref(ref, sb.commit.sha)
            return branch_name
        except Exception:
            try:
                self.repo.get_git_ref(f"heads/{branch_name}")
                return branch_name
            except Exception:
                return None

    def update_or_create_files(self, branch: str, changes: List[dict], commit_message: str = "assistant: propose changes") -> List[str]:
        """changes: list of {path, content}"""
        if not self.repo:
            return []
        changed = []
        for ch in changes:
            path = ch.get("path")
            content = ch.get("content")
            try:
                # try get existing file on branch
                try:
                    existing = self.repo.get_contents(path, ref=branch)
                    self.repo.update_file(path, commit_message, content, existing.sha, branch=branch)
                except Exception:
                    self.repo.create_file(path, commit_message, content, branch=branch)
                changed.append(path)
            except Exception:
                continue
        return changed

    def get_branch_diff(self, branch: str, base: Optional[str] = None):
        if not self.repo:
            return None
        base_branch = base or self.default_branch or "master"
        try:
            comp = self.repo.compare(base_branch, branch)
            files = []
            for f in comp.files:
                files.append({
                    "filename": f.filename,
                    "status": f.status,
                    "additions": f.additions,
                    "deletions": f.deletions,
                    "patch": getattr(f, "patch", None),
                })
            return {"base": base_branch, "branch": branch, "files": files}
        except Exception:
            return None

    def create_pull_request(self, title: str, body: str, head_branch: str, base: Optional[str] = None):
        if not self.repo:
            if self.local_path:
                return {
                    "url": f"https://github.com/{self.repo_full_name or 'local/repo'}/pull/mock",
                    "number": 1,
                    "title": title,
                    "already_existed": False
                }
            raise ValueError("No GitHub repository configured")

        base_branch = base or self.default_branch or "master"

        # 1. Attempt to create the PR directly
        try:
            pr = self.repo.create_pull(title=title, body=body or "", head=head_branch, base=base_branch)
            return {
                "url": pr.html_url,
                "number": pr.number,
                "title": pr.title,
                "already_existed": False
            }
        except Exception as exc:
            # 2. If creation fails (e.g. 422 PR already exists), check if an open PR already exists for head_branch
            try:
                owner_login = getattr(getattr(self.repo, "owner", None), "login", None)
                head_spec = f"{owner_login}:{head_branch}" if owner_login else head_branch
                prs = list(self.repo.get_pulls(head=head_spec, state="open"))
                if not prs and owner_login:
                    prs = list(self.repo.get_pulls(head=head_branch, state="open"))
                if prs:
                    pr = prs[0]
                    return {
                        "url": pr.html_url,
                        "number": pr.number,
                        "title": pr.title,
                        "already_existed": True
                    }
            except Exception:
                pass

            # 3. Format real error message from PyGithub exception
            error_msg = str(exc)
            if hasattr(exc, "data") and isinstance(exc.data, dict):
                msg_part = exc.data.get("message", "")
                errors_part = exc.data.get("errors", [])
                if msg_part and errors_part:
                    error_msg = f"{msg_part}: {errors_part}"
                elif msg_part:
                    error_msg = msg_part
            elif hasattr(exc, "status"):
                error_msg = f"GitHub API Error ({exc.status}): {str(exc)}"

            raise ValueError(error_msg)

    def delete_file(self, path: str, branch: str, message: Optional[str] = None) -> dict:
        clean_path = (path or "").strip().lstrip("/")
        if not clean_path:
            raise ValueError("File path cannot be empty")

        target_branch = (branch or "").strip()
        default_branch = self.default_branch or "master"
        if not target_branch or target_branch.lower() == default_branch.lower():
            raise ValueError(f"Deleting files directly on default branch '{default_branch}' is not allowed. Please specify a non-default feature branch.")

        # 1. GitHub API Mode
        if self.repo:
            try:
                content_file = self.repo.get_contents(clean_path, ref=target_branch)
                if isinstance(content_file, list):
                    raise ValueError(f"Path '{clean_path}' is a directory, not a file")

                msg = message or f"Delete {clean_path}"
                res = self.repo.delete_file(clean_path, msg, content_file.sha, branch=target_branch)

                commit_sha = ""
                if isinstance(res, dict) and "commit" in res:
                    commit_sha = getattr(res["commit"], "sha", str(res["commit"]))
                elif hasattr(res, "commit"):
                    commit_sha = getattr(res.commit, "sha", str(res.commit))

                return {
                    "path": clean_path,
                    "branch": target_branch,
                    "deleted": True,
                    "sha": commit_sha or content_file.sha
                }
            except ValueError:
                raise
            except Exception as exc:
                raise FileNotFoundError(f"File '{clean_path}' not found on branch '{target_branch}'")

        # 2. Local Fallback Mode
        if self.local_path:
            full_p = os.path.normpath(os.path.join(self.local_path, clean_path))
            if not os.path.exists(full_p):
                raise FileNotFoundError(f"File '{clean_path}' not found on branch '{target_branch}'")
            if os.path.isdir(full_p):
                raise ValueError(f"Path '{clean_path}' is a directory, not a file")

            import hashlib
            with open(full_p, "rb") as f:
                data = f.read()
            old_sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()

            try:
                os.remove(full_p)
            except Exception as e:
                raise ValueError(f"Failed to delete file '{clean_path}': {str(e)}")

            new_commit_sha = hashlib.sha1(f"delete {clean_path} {old_sha}".encode()).hexdigest()
            return {
                "path": clean_path,
                "branch": target_branch,
                "deleted": True,
                "sha": new_commit_sha
            }

        raise FileNotFoundError(f"File '{clean_path}' not found")


    def _resolve_branch(self, branch: Optional[str]) -> str:
        target = branch or self.default_branch or "master"
        if self.repo and target == "master" and self.default_branch != "master":
            try:
                self.repo.get_branch("master")
            except Exception:
                target = self.default_branch
        return target


    def list_directory(self, path: str = "", recursive: bool = False, branch: Optional[str] = None) -> dict:
        clean_path = (path or "").strip().lstrip("/")
        target_branch = self._resolve_branch(branch)


        # 1. GitHub API Mode
        if self.repo:
            try:
                if recursive:
                    entries = []
                    try:
                        commit_sha = self.repo.get_branch(target_branch).commit.sha
                        tree = self.repo.get_git_tree(commit_sha, recursive=True)
                        prefix = (clean_path + "/") if clean_path else ""
                        for element in tree.tree:
                            if not prefix or element.path.startswith(prefix):
                                rel_name = element.path.split("/")[-1]
                                entry_type = "dir" if element.type == "tree" else "file"
                                entries.append({
                                    "name": rel_name,
                                    "type": entry_type,
                                    "path": element.path
                                })
                    except Exception:
                        stack = [clean_path]
                        visited = set()
                        while stack:
                            curr = stack.pop()
                            if curr in visited:
                                continue
                            visited.add(curr)
                            contents = self.repo.get_contents(curr, ref=target_branch)
                            if isinstance(contents, list):
                                for c in contents:
                                    entry_type = "dir" if c.type == "dir" else "file"
                                    entries.append({
                                        "name": c.name,
                                        "type": entry_type,
                                        "path": c.path
                                    })
                                    if c.type == "dir":
                                        stack.append(c.path)
                    entries.sort(key=lambda x: x["path"])
                    return {"path": clean_path, "entries": entries}
                else:
                    contents = self.repo.get_contents(clean_path, ref=target_branch)
                    if not isinstance(contents, list):
                        raise ValueError(f"Path '{clean_path}' is a file, not a directory")
                    entries = []
                    for c in contents:
                        entry_type = "dir" if c.type == "dir" else "file"
                        entries.append({
                            "name": c.name,
                            "type": entry_type,
                            "path": c.path
                        })
                    entries.sort(key=lambda x: x["path"])
                    return {"path": clean_path, "entries": entries}
            except ValueError:
                raise
            except Exception:
                raise FileNotFoundError(f"Directory '{clean_path}' not found on branch '{target_branch}'")

        # 2. Local Fallback Mode
        if self.local_path:
            target_dir = os.path.normpath(os.path.join(self.local_path, clean_path)) if clean_path else self.local_path
            if not os.path.exists(target_dir):
                raise FileNotFoundError(f"Directory '{clean_path}' not found")
            if not os.path.isdir(target_dir):
                raise ValueError(f"Path '{clean_path}' is a file, not a directory")

            entries = []
            if recursive:
                for root, dirs, files in os.walk(target_dir):
                    for d in dirs:
                        full_p = os.path.join(root, d)
                        rel_p = os.path.relpath(full_p, self.local_path).replace("\\", "/")
                        entries.append({"name": d, "type": "dir", "path": rel_p})
                    for f in files:
                        full_p = os.path.join(root, f)
                        rel_p = os.path.relpath(full_p, self.local_path).replace("\\", "/")
                        entries.append({"name": f, "type": "file", "path": rel_p})
            else:
                for name in os.listdir(target_dir):
                    full_p = os.path.join(target_dir, name)
                    rel_p = os.path.relpath(full_p, self.local_path).replace("\\", "/")
                    entry_type = "dir" if os.path.isdir(full_p) else "file"
                    entries.append({"name": name, "type": entry_type, "path": rel_p})

            entries.sort(key=lambda x: x["path"])
            return {"path": clean_path, "entries": entries}

        raise FileNotFoundError(f"Directory '{clean_path}' not found")

    def get_file_content(self, path: str, branch: Optional[str] = None) -> dict:
        clean_path = (path or "").strip().lstrip("/")
        target_branch = self._resolve_branch(branch)


        # 1. GitHub API Mode
        if self.repo:
            try:
                c = self.repo.get_contents(clean_path, ref=target_branch)
                if isinstance(c, list):
                    raise ValueError(f"Path '{clean_path}' is a directory, not a file")
                if getattr(c, "size", 0) > 2000000:
                    raise ValueError("File is too large to return as text (exceeds 2MB limit)")

                raw_bytes = c.decoded_content
                try:
                    text = raw_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    raise ValueError("File is binary and cannot be returned as text")

                return {
                    "path": clean_path,
                    "branch": target_branch,
                    "content": text,
                    "sha": c.sha
                }
            except ValueError:
                raise
            except Exception:
                raise FileNotFoundError(f"File '{clean_path}' not found on branch '{target_branch}'")

        # 2. Local Fallback Mode
        if self.local_path:
            full_p = os.path.normpath(os.path.join(self.local_path, clean_path))
            if not os.path.exists(full_p):
                raise FileNotFoundError(f"File '{clean_path}' not found")
            if os.path.isdir(full_p):
                raise ValueError(f"Path '{clean_path}' is a directory, not a file")
            if os.path.getsize(full_p) > 2000000:
                raise ValueError("File is too large to return as text (exceeds 2MB limit)")

            try:
                with open(full_p, "rb") as f:
                    data = f.read()
                text = data.decode("utf-8")
            except UnicodeDecodeError:
                raise ValueError("File is binary and cannot be returned as text")
            except Exception as e:
                raise FileNotFoundError(f"Could not read file '{clean_path}': {str(e)}")

            import hashlib
            sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()

            return {
                "path": clean_path,
                "branch": target_branch,
                "content": text,
                "sha": sha
            }

        raise FileNotFoundError(f"File '{clean_path}' not found")

