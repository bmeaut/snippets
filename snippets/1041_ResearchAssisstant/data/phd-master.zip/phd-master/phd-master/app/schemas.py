from pydantic import BaseModel
from typing import List, Optional


class FileRequest(BaseModel):
    path: str


class FileResponse(BaseModel):
    path: str
    content: Optional[str]


class CommitSummary(BaseModel):
    sha: str
    message: str
    author: Optional[str]


class ProjectContextResponse(BaseModel):
    repo: str
    top_level: List[str]
    readme: Optional[str]
    project_guide: Optional[str]
    recent_commits: List[CommitSummary]


class ChangeItem(BaseModel):
    path: str
    content: str


class ProposeChangesRequest(BaseModel):
    branch_name: Optional[str]
    summary: Optional[str]
    conversation_id: Optional[str]
    changes: List[ChangeItem]


class ProposeChangesResponse(BaseModel):
    branch: str
    files_changed: List[str]
    message: Optional[str]


class DiffFile(BaseModel):
    filename: str
    status: Optional[str]
    additions: Optional[int]
    deletions: Optional[int]
    patch: Optional[str]


class DiffResponse(BaseModel):
    branch: str
    base: str
    files: List[DiffFile]


class CreatePRRequest(BaseModel):
    branch: str
    title: str
    description: Optional[str] = None
    base: Optional[str] = "master"


class CreatePRResponse(BaseModel):
    url: Optional[str]
    number: Optional[int]
    title: Optional[str]
    already_existed: Optional[bool] = False


class StartThreadRequest(BaseModel):
    name: Optional[str]


class StartThreadResponse(BaseModel):
    thread_id: str
    name: Optional[str]


class PlanRequest(BaseModel):
    thread_id: str
    instruction: str


class PlanResponse(BaseModel):
    thread_id: str
    proposed_changes: List[ChangeItem]
    summary: Optional[str]


class DirectoryEntry(BaseModel):
    name: str
    type: str
    path: str


class ListDirectoryRequest(BaseModel):
    path: Optional[str] = ""
    recursive: Optional[bool] = False
    branch: Optional[str] = "master"


class ListDirectoryResponse(BaseModel):
    path: str
    entries: List[DirectoryEntry]


class GetFileContentRequest(BaseModel):
    path: str
    branch: Optional[str] = "master"


class GetFileContentResponse(BaseModel):
    path: str
    branch: str
    content: str
    sha: str


class DeleteFileRequest(BaseModel):
    path: str
    branch: str
    message: Optional[str] = None


class DeleteFileResponse(BaseModel):
    path: str
    branch: str
    deleted: bool = True
    sha: str


