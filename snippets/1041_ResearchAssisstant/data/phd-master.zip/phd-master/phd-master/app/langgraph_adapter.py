"""LangGraph adapter: uses real LangGraph SDK if available, otherwise falls back to the
file-backed LangGraphManager. This file provides a stable factory for the rest of
the codebase to request an orchestration manager.
"""
from typing import Optional
import logging
from .langgraph_manager import LangGraphManager
from .langgraph_remote import RemoteLangGraphManager
import os
from .langgraph_mock import MockLangGraphManager

logger = logging.getLogger("langgraph_adapter")


def get_manager(storage_dir: Optional[str] = None, gh_client=None):
    # Prefer a hosted LangGraph endpoint when configured via env
    base_url = os.getenv("LANGGRAPH_URL")
    api_key = os.getenv("LANGGRAPH_API_KEY")
    mock = os.getenv("MOCK_LANGGRAPH", "0")
    if mock in ("1", "true", "True"):
        logger.info("Using in-process mock LangGraph manager (MOCK_LANGGRAPH=1)")
        return MockLangGraphManager(gh_client=gh_client)
    if base_url:
        logger.info("Using remote LangGraph at %s", base_url)
        return RemoteLangGraphManager(base_url, api_key, gh_client=gh_client)

    try:
        import langgraph  # type: ignore
        logger.info("langgraph SDK detected — SDK integration not implemented, using placeholder")
    except Exception:
        logger.info("langgraph SDK not available; using local placeholder manager")

    return LangGraphManager(storage_dir=storage_dir, gh_client=gh_client)
