"""
MCP Server for PhD Research Assistant
Exposes tools via Model Context Protocol (MCP) for use with Claude desktop
"""
import os
import httpx
import json
import logging
try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    try:
        from mcp.server import FastMCP
    except ImportError:
        from mcp.server import MCPServer as FastMCP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mcp_server")

# Get API URL from environment or default to local
API_BASE_URL = os.getenv("PHDA_API_URL", "https://phd-l3gd.onrender.com")
API_KEY = os.getenv("PHDA_API_KEY", "")

# Create MCP server
mcp = FastMCP("phd-research-assistant")
client = httpx.Client(timeout=30.0)

def _headers():
    headers = {"Content-Type": "application/json"}
    if API_KEY:
        headers["Authorization"] = f"Bearer {API_KEY}"
    return headers

@mcp.tool()
def get_project_context() -> str:
    """Fetch project context including repo info, README, and recent commits"""
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/get_project_context",
            headers=_headers()
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"get_project_context failed: {e}")
        return json.dumps({"error": str(e)})

@mcp.tool()
def start_thread(name: str) -> str:
    """Start a new research thread for a conversation"""
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/start_thread",
            headers=_headers(),
            json={"name": name}
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"start_thread failed: {e}")
        return json.dumps({"error": str(e)})

@mcp.tool()
def plan_changes(thread_id: str, instruction: str) -> str:
    """Plan proposed changes to files based on an instruction"""
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/plan_changes",
            headers=_headers(),
            json={
                "thread_id": thread_id,
                "instruction": instruction
            }
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"plan_changes failed: {e}")
        return json.dumps({"error": str(e)})

@mcp.tool()
def propose_changes(conversation_id: str, summary: str, changes: list, branch_name: str = None) -> str:
    """Propose changes by creating a branch with file modifications
    
    Args:
        conversation_id: Identifier for this change request
        summary: Summary of changes
        changes: List of dicts with 'path' and 'content' keys
        branch_name: Optional custom branch name (auto-generated if not provided)
    """
    try:
        payload = {
            "conversation_id": conversation_id,
            "summary": summary,
            "branch_name": branch_name,
            "changes": changes
        }
        r = client.post(
            f"{API_BASE_URL}/mcp/propose_changes",
            headers=_headers(),
            json=payload
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"propose_changes failed: {e}")
        return json.dumps({"error": str(e)})

@mcp.tool()
def get_diff(branch: str) -> str:
    """Get the diff for a proposed branch"""
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/get_diff",
            headers=_headers(),
            params={"branch": branch}
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"get_diff failed: {e}")
        return json.dumps({"error": str(e)})

@mcp.tool()
def create_pull_request(title: str, description: str, branch: str, base: str = None) -> str:
    """Create a pull request to merge a branch
    
    Args:
        title: PR title
        description: PR description
        branch: Branch to merge (from)
        base: Optional base branch to merge into (defaults to repo default)
    """
    try:
        payload = {
            "title": title,
            "description": description,
            "branch": branch
        }
        if base:
            payload["base"] = base
        r = client.post(
            f"{API_BASE_URL}/mcp/create_pull_request",
            headers=_headers(),
            json=payload
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"create_pull_request failed: {e}")
        return json.dumps({"error": str(e)})


@mcp.tool()
def list_directory(path: str = "", recursive: bool = False, branch: str = "master") -> str:
    """List files and subdirectories at a given path in the repository.
    
    Args:
        path: Path in repo (default: "" for root)
        recursive: If True, walks the whole subtree under path
        branch: Target branch to inspect (default: "master")
    """
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/list_directory",
            headers=_headers(),
            json={
                "path": path,
                "recursive": recursive,
                "branch": branch
            }
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"list_directory failed: {e}")
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_file_content(path: str, branch: str = "master") -> str:
    """Fetch raw text content of a single file at a given path and branch.
    
    Args:
        path: File path in repository
        branch: Target branch (default: "master")
    """
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/get_file_content",
            headers=_headers(),
            json={
                "path": path,
                "branch": branch
            }
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
@mcp.tool()
def delete_file(path: str, branch: str, message: str = None) -> str:
    """Delete a file at a given path on a non-default feature branch.
    
    Args:
        path: File path in repository
        branch: Non-default target branch (deleting on default branch is prohibited)
        message: Optional commit message for the deletion
    """
    try:
        r = client.post(
            f"{API_BASE_URL}/mcp/delete_file",
            headers=_headers(),
            json={
                "path": path,
                "branch": branch,
                "message": message
            }
        )
        r.raise_for_status()
        return json.dumps(r.json(), indent=2)
    except Exception as e:
        logger.error(f"delete_file failed: {e}")
        return json.dumps({"error": str(e)})




def create_mcp_server():
    """Return the configured MCP server"""
    return mcp


if __name__ == "__main__":
    mcp.run()
