import os
import json
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List


class LangGraphManager:
    """Lightweight orchestration placeholder that checkpoints conversation state
    and generates simple proposed changes. Designed to be replaced by a real
    LangGraph integration later.
    """

    def __init__(self, storage_dir: Optional[str] = None, gh_client=None):
        self.storage_dir = storage_dir or os.path.join(os.getcwd(), ".langgraph")
        os.makedirs(self.storage_dir, exist_ok=True)
        self.gh = gh_client

    def _thread_path(self, thread_id: str) -> str:
        return os.path.join(self.storage_dir, f"thread_{thread_id}.json")

    def create_thread(self, name: Optional[str] = None, initial_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        tid = uuid.uuid4().hex[:12]
        data = {
            "thread_id": tid,
            "name": name or f"thread-{tid}",
            "created": datetime.utcnow().isoformat() + "Z",
            "context": initial_context or {},
            "history": [],
            "checkpoints": [],
        }
        with open(self._thread_path(tid), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return data

    def get_thread(self, thread_id: str) -> Optional[Dict[str, Any]]:
        p = self._thread_path(thread_id)
        if not os.path.exists(p):
            return None
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)

    def checkpoint(self, thread_id: str, state: Dict[str, Any]) -> bool:
        t = self.get_thread(thread_id)
        if t is None:
            return False
        t["checkpoints"].append({"ts": datetime.utcnow().isoformat() + "Z", "state": state})
        with open(self._thread_path(thread_id), "w", encoding="utf-8") as f:
            json.dump(t, f, ensure_ascii=False, indent=2)
        return True

    def plan_changes(self, thread_id: str, instruction: str) -> List[Dict[str, str]]:
        """Produce a simple proposed change set based on the instruction.
        Strategy (MVP): if the repo contains PROJECT_GUIDE.md, propose appending
        an item describing the instruction. Otherwise create a new decision file
        under `08_DECISIONS/`.
        """
        proposals = []
        # Heuristic: extract keywords from instruction and search repo for candidate files
        terms = [t.strip().lower() for t in instruction.split() if len(t.strip()) > 3]
        query = " ".join(terms[:6])
        candidates: List[dict] = []
        if self.gh and query:
            candidates = self.gh.search_repository(query, max_results=10)

        if candidates:
            # pick top candidate and propose appending a noted entry
            top = candidates[0]
            path = top.get("path")
            existing = self.gh.get_file(path) if self.gh else None
            if existing is None:
                # create a new file at the candidate path
                new_content = f"# Notes\n\n{instruction}\n"
            else:
                new_content = existing + "\n\n" + f"## Proposed note ({datetime.utcnow().isoformat()}):\n{instruction}\n"
            proposals.append({"path": path, "content": new_content})
        else:
            # fallback: create a decision file
            fname = f"08_DECISIONS/decision_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.md"
            content = f"# Decision created from conversation {thread_id}\n\n{instruction}\n"
            proposals.append({"path": fname, "content": content})

        # persist a short plan in the thread checkpoint
        self.checkpoint(thread_id, {"planned_changes": proposals, "instruction": instruction})
        return proposals
