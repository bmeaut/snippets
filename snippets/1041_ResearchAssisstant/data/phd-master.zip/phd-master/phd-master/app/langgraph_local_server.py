from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional
from datetime import datetime
import uuid
import os

app = FastAPI(title="Local LangGraph Mock Server")


class CreateThreadRequest(BaseModel):
    name: Optional[str]
    context: Optional[Dict[str, Any]]


class PlanRequest(BaseModel):
    instruction: str


# In-memory store for threads
THREADS: Dict[str, Dict[str, Any]] = {}


@app.post("/threads")
def create_thread(req: CreateThreadRequest):
    tid = uuid.uuid4().hex[:12]
    t = {
        "thread_id": tid,
        "name": req.name or f"thread-{tid}",
        "created": datetime.utcnow().isoformat() + "Z",
        "context": req.context or {},
        "history": [],
        "checkpoints": [],
    }
    THREADS[tid] = t
    return t


@app.get("/threads/{thread_id}")
def get_thread(thread_id: str):
    t = THREADS.get(thread_id)
    if not t:
        raise HTTPException(status_code=404, detail="thread not found")
    return t


@app.post("/threads/{thread_id}/checkpoint")
def checkpoint(thread_id: str, body: Dict[str, Any]):
    t = THREADS.get(thread_id)
    if not t:
        raise HTTPException(status_code=404, detail="thread not found")
    t.setdefault("checkpoints", []).append({"ts": datetime.utcnow().isoformat() + "Z", "state": body.get("state")})
    return {"status": "ok"}


@app.post("/threads/{thread_id}/plan")
def plan(thread_id: str, req: PlanRequest):
    t = THREADS.get(thread_id)
    if not t:
        raise HTTPException(status_code=404, detail="thread not found")
    # Very small heuristic proposal: create a decision file entry
    fname = f"08_DECISIONS/decision_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.md"
    content = f"# Decision created from conversation {thread_id}\n\n{req.instruction}\n"
    proposal = {"path": fname, "content": content}
    # save as checkpoint
    t.setdefault("checkpoints", []).append({"ts": datetime.utcnow().isoformat() + "Z", "planned": [proposal]})
    return {"proposals": [proposal]}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("LANGGRAPH_MOCK_PORT", "9001"))
    uvicorn.run("app.langgraph_local_server:app", host="0.0.0.0", port=port, reload=False)
