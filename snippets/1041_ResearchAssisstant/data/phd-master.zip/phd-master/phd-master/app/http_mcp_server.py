"""
HTTP MCP Server for PhD Research Assistant
Runs on Render and provides MCP over HTTP/SSE for Claude Desktop/Mobile remote connections
"""
import os
import json
import logging
from datetime import datetime, timezone

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    try:
        from mcp.server import FastMCP
    except ImportError:
        from mcp.server import MCPServer as FastMCP
from mcp.server.sse import SseServerTransport
from fastapi import FastAPI, Request

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("http_mcp_server")

# Create MCP server
mcp = FastMCP("phd-research-assistant")


@mcp.tool()
async def get_project_context() -> str:
    """Fetch project context including repo info, README, and recent commits"""
    try:
        from .main import get_gh_client
        client = get_gh_client()
        repo = client.repo_full_name or "local"
        top = client.list_top_level()
        readme = client.get_file("README.md")
        guide = client.get_file("PROJECT_GUIDE.md")
        commits = [
            {"sha": c.get("sha"), "message": c.get("message"), "author": c.get("author")}
            for c in client.recent_commits(5)
        ]
        res = {
            "repo": repo,
            "top_level": top,
            "readme": readme,
            "project_guide": guide,
            "recent_commits": commits,
        }
        return json.dumps(res, indent=2)
    except Exception as e:
        logger.error(f"get_project_context failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def start_thread(name: str) -> str:
    """Start a new research thread for a conversation"""
    try:
        from .main import get_gh_client, lg, audit_log
        client = get_gh_client()
        ctx = {
            "repo": client.repo_full_name,
            "top_level": client.list_top_level(),
            "project_guide_exists": bool(client.get_file("PROJECT_GUIDE.md")),
        }
        t = lg.create_thread(name=name, initial_context=ctx)
        audit_log({"tool": "start_thread", "thread_id": t.get("thread_id"), "name": t.get("name"), "repo": client.repo_full_name})
        return json.dumps({"thread_id": t.get("thread_id"), "name": t.get("name")}, indent=2)
    except Exception as e:
        logger.error(f"start_thread failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def plan_changes(thread_id: str, instruction: str) -> str:
    """Plan proposed changes to files based on an instruction"""
    try:
        from .main import lg, audit_log
        t = lg.get_thread(thread_id)
        if t is None:
            return json.dumps({"error": f"Thread '{thread_id}' not found"})
        proposals = lg.plan_changes(thread_id, instruction)
        changes = [{"path": p.get("path"), "content": p.get("content")} for p in proposals]
        audit_log({"tool": "plan_changes", "thread_id": thread_id, "num_changes": len(changes)})
        return json.dumps({"thread_id": thread_id, "proposed_changes": changes, "summary": f"Proposed {len(changes)} change(s)"}, indent=2)
    except Exception as e:
        logger.error(f"plan_changes failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def propose_changes(conversation_id: str, summary: str, changes: list, branch_name: str = None) -> str:
    """Propose changes by creating a branch with file modifications"""
    try:
        from .main import get_gh_client, audit_log
        client = get_gh_client()
        branch = branch_name or f"assistant/proposal-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        created = client.create_branch(branch)
        if created is None:
            return json.dumps({"error": f"Failed to create branch '{branch}'. Please check GitHub token/permissions."})
        changed = client.update_or_create_files(branch, changes, commit_message=summary or "assistant: propose changes")
        audit_log({"conversation_id": conversation_id, "tool": "propose_changes", "repo": client.repo_full_name, "branch": branch, "files_changed": changed})
        return json.dumps({"branch": branch, "files_changed": changed, "message": "proposed"}, indent=2)
    except Exception as e:
        logger.error(f"propose_changes failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_diff(branch: str) -> str:
    """Get the diff for a proposed branch"""
    try:
        from .main import get_gh_client
        client = get_gh_client()
        diff = client.get_branch_diff(branch)
        if diff is None:
            return json.dumps({"error": f"Diff for branch '{branch}' not available."})
        return json.dumps(diff, indent=2)
    except Exception as e:
        logger.error(f"get_diff failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def create_pull_request(title: str, description: str, branch: str, base: str = None) -> str:
    """Create a pull request to merge a branch"""
    try:
        from .main import get_gh_client, audit_log
        client = get_gh_client()
        base_branch = base or client.default_branch or "master"
        pr = client.create_pull_request(title, description or "", branch, base=base_branch)
        audit_log({"tool": "create_pull_request", "repo": client.repo_full_name, "branch": branch, "pr_url": pr.get("url"), "pr_number": pr.get("number"), "already_existed": pr.get("already_existed", False)})
        return json.dumps({
            "url": pr.get("url"),
            "number": pr.get("number"),
            "title": pr.get("title"),
            "already_existed": pr.get("already_existed", False)
        }, indent=2)
    except ValueError as e:
        return json.dumps({"error": f"Bad request: {str(e)}"})
    except Exception as e:
        logger.error(f"create_pull_request failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def list_directory(path: str = "", recursive: bool = False, branch: str = "master") -> str:
    """List files and subdirectories at a given path in the repository.
    
    Args:
        path: Path in repo (default: "" for root)
        recursive: If True, walks the whole subtree under path
        branch: Target branch to inspect (default: "master")
    """
    try:
        from .main import get_gh_client
        client = get_gh_client()
        res = client.list_directory(path=path, recursive=recursive, branch=branch)
        return json.dumps(res, indent=2)
    except FileNotFoundError as e:
        return json.dumps({"error": f"Not found: {str(e)}"})
    except ValueError as e:
        return json.dumps({"error": f"Bad request: {str(e)}"})
    except Exception as e:
        logger.error(f"list_directory failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_file_content(path: str, branch: str = "master") -> str:
    """Fetch raw text content of a single file at a given path and branch.
    
    Args:
        path: File path in repository
        branch: Target branch (default: "master")
    """
    try:
        from .main import get_gh_client
        client = get_gh_client()
        res = client.get_file_content(path=path, branch=branch)
        return json.dumps(res, indent=2)
    except FileNotFoundError as e:
        return json.dumps({"error": f"Not found: {str(e)}"})
    except ValueError as e:
        return json.dumps({"error": f"Bad request: {str(e)}"})
    except Exception as e:
        logger.error(f"get_file_content failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


@mcp.tool()
async def delete_file(path: str, branch: str, message: str = None) -> str:
    """Delete a file at a given path on a non-default feature branch.
    
    Args:
        path: File path in repository
        branch: Non-default target branch (deleting on default branch is prohibited)
        message: Optional commit message for the deletion
    """
    try:
        from .main import get_gh_client, audit_log
        client = get_gh_client()
        default_branch = client.default_branch or "master"
        if not branch or branch.strip().lower() == default_branch.lower():
            return json.dumps({"error": f"Bad request: Deleting files directly on default branch '{default_branch}' is not allowed. Please specify a non-default feature branch."})
        res = client.delete_file(path=path, branch=branch, message=message)
        audit_log({"tool": "delete_file", "path": path, "branch": branch, "sha": res.get("sha")})
        return json.dumps(res, indent=2)
    except FileNotFoundError as e:
        return json.dumps({"error": f"Not found: {str(e)}"})
    except ValueError as e:
        return json.dumps({"error": f"Bad request: {str(e)}"})
    except Exception as e:
        logger.error(f"delete_file failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})




# FastAPI app for HTTP/SSE transport
app = FastAPI(title="PhD Research Assistant MCP HTTP Server")


@app.get("/mcp/sse")
async def mcp_sse(request: Request):
    """SSE endpoint for MCP protocol"""
    async with SseServerTransport(request.scope["path"]) as transport:
        async with mcp.client_session(transport):
            await transport.run()


@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "ok", "service": "mcp-server"}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8001))
    uvicorn.run(app, host="0.0.0.0", port=port)
